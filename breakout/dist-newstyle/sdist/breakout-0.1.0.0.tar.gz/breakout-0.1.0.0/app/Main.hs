module Main (main) where

import UI (main)
import Brick (simpleMain)
import Breakout (Breakout)

main :: IO ()
main = main 
